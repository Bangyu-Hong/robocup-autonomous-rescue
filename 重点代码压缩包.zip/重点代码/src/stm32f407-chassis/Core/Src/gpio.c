/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, motorD_IN1_Pin|motorD_IN2_Pin|motorC_IN1_Pin|motorA_IN1_Pin
                          |motorA_IN2_Pin|motorB_IN1_Pin|motorB_IN2_Pin|motorC_IN2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : motorD_IN1_Pin motorD_IN2_Pin motorC_IN1_Pin motorA_IN1_Pin
                           motorA_IN2_Pin motorB_IN1_Pin motorB_IN2_Pin motorC_IN2_Pin */
  GPIO_InitStruct.Pin = motorD_IN1_Pin|motorD_IN2_Pin|motorC_IN1_Pin|motorA_IN1_Pin
                          |motorA_IN2_Pin|motorB_IN1_Pin|motorB_IN2_Pin|motorC_IN2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : KEY_Pin (PA0, 高电平触发) */
  GPIO_InitStruct.Pin = KEY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;  // ★★★ 下拉，高电平触发 ★★★
  HAL_GPIO_Init(KEY_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 2 */
// ★★★ KEY按键扫描 (PA0, 高电平触发) ★★★
uint8_t key_scan(void)
{
    uint8_t temp = 0;
    // 高电平触发：按下时读到1，直接返回
    temp = HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin);

    return temp;
}
/* USER CODE END 2 */

# ROS 1 环境建图重点代码

包含 ROS 1 建图工作空间、STM32F407 底盘源码和运行说明。
建图入口与环境见 src/docs/SETUP.md。
完整项目：https://github.com/Bangyu-Hong/robocup-autonomous-rescue
本次未执行 ROS / Keil 编译或实机复测。
